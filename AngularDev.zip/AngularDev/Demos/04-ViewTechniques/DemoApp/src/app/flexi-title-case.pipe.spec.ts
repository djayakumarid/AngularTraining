import { FlexiTitleCasePipe } from './flexi-title-case.pipe';

describe('FlexiTitleCasePipe', () => {
  it('create an instance', () => {
    const pipe = new FlexiTitleCasePipe();
    expect(pipe).toBeTruthy();
  });
});
