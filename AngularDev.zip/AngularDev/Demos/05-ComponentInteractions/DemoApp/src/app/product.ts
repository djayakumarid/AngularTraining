export class Product {
    constructor(
        public description: string, 
        public category: string, 
        public price: number) 
        {}
}
  