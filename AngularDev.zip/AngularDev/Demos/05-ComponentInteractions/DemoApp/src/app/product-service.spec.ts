import { ProductService } from './product-service';

describe('ProductService', () => {
  it('should create an instance', () => {
    expect(new ProductService()).toBeTruthy();
  });
});
